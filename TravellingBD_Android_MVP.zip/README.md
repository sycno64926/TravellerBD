# TravellingBD Android MVP

A native Android shell (WebView) around the TravellingBD offline-first travel guide UI.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Unzip this project.
3. In Android Studio choose **Open** and select the `TravellingBD_Android` folder.
4. Wait for Gradle sync. If prompted, install Android Gradle Plugin / SDK components.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone and install it. You may need to allow installing apps from that file manager.

## Included in this MVP
- Bengali home screen and destination cards
- Search destinations
- Favorite destinations (saved locally on the device)
- Mark visited districts (saved locally)
- District checklist for all 64 districts
- Simple trip budget planner
- Travel quiz
- Bottom navigation

## Notes
- Destination photos use public Unsplash image URLs and need internet access.
- Favorites, visited districts, and the trip plan are stored locally in the app's WebView storage.
- This is a starter MVP, not a production booking service. It does not yet include user accounts, live maps, verified hotel inventory, or server-side submissions.
